var app = {};

app.host = 'http://localhost:8000/';
