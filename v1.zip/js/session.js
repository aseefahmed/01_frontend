if(sessionStorage.getItem('loginUser') == null)
    window.location.href = 'login';